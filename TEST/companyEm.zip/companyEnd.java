package 자바객체프로젝트;

public class companyEnd {
	
	String cId = null;
	String cName = null;
	

	public void view() {
		System.out.println("구인완료 된 회사의 ID : "+cId);
		System.out.println("구인완료 된 회사의 이름 : "+cName);
	}

}
