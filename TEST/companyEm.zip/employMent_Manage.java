package 자바객체프로젝트;

public class employMent_Manage {
	
	String mId = null;
	String mName = null;
	String mAge = null;

	public void view() {
		System.out.println("취업완료 된 사람의 ID : "+mId);
		System.out.println("취업완료 된 사람의 이름 : "+mName);
	}

}
